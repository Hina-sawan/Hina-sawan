/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bank;

/**
 *
 * @author DELL
 */
class Bank{
private String AccountHolder;
private double Balance;
Bank(String AccountHolder,double Balance){
    this.AccountHolder=AccountHolder;
    this.Balance=Balance;
}
void deposit(double amount){
   if(amount>0) {
   Balance+=amount;
   System.out.println("----------------------------------");
   System.out.println("You have deposited : "+amount);
   }
   else{
       System.out.println("----------------------------------");
   System.out.println("You entered invalid amount");
   }
}
void withdraw(double amount){
    if(amount<=0){
        System.out.println("----------------------------------");
        System.out.println("You entered invalid amount");
    }
    else if(amount>Balance){
        System.out.println("----------------------------------");
      System.out.println("You have not sufficient Balance"); 
}
    else{
        Balance-=amount;
        System.out.println("----------------------------------");
    System.out.println("Your withdrawel amount is:"+amount);
    System.out.println("----------------------------------");
    System.out.println("Your remaining balance is:"+Balance);
    System.out.println("----------------------------------");
    }
    }
void displayBalance() {
        System.out.println("----------------------------------");
        System.out.println("Account Holder: " + AccountHolder);
        System.out.println("Current Balance: $" + Balance);
        System.out.println("----------------------------------");
    }
    public static void main(String[] args){
  Bank MyAcc =new Bank("Hina Sawan",58.00);
  MyAcc.displayBalance();
  MyAcc.deposit(5911.295);
  MyAcc.displayBalance();
  MyAcc.withdraw(5969.295);
  MyAcc.displayBalance();
}
}
